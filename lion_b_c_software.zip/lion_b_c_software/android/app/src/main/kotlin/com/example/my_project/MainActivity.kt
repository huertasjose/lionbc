package com.LionBCSOftware.homeU

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
