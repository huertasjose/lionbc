import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'error_compartido_widget.dart' show ErrorCompartidoWidget;
import 'package:flutter/material.dart';

class ErrorCompartidoModel extends FlutterFlowModel<ErrorCompartidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
