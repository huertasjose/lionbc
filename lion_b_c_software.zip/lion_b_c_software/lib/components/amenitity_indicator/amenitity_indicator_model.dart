import '/flutter_flow/flutter_flow_util.dart';
import 'amenitity_indicator_widget.dart' show AmenitityIndicatorWidget;
import 'package:flutter/material.dart';

class AmenitityIndicatorModel
    extends FlutterFlowModel<AmenitityIndicatorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
