import '/flutter_flow/flutter_flow_util.dart';
import 'total_widget.dart' show TotalWidget;
import 'package:flutter/material.dart';

class TotalModel extends FlutterFlowModel<TotalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
