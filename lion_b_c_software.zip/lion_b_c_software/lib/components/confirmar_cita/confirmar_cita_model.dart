import '/flutter_flow/flutter_flow_util.dart';
import 'confirmar_cita_widget.dart' show ConfirmarCitaWidget;
import 'package:flutter/material.dart';

class ConfirmarCitaModel extends FlutterFlowModel<ConfirmarCitaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
