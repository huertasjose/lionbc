// Export pages
export '/pages/admin/barbers_review/barbers_review_widget.dart'
    show BarbersReviewWidget;
export '/pages/normal_user/editar_perfil/editar_perfil_widget.dart'
    show EditarPerfilWidget;
export '/pages/auth/change_password/change_password_widget.dart'
    show ChangePasswordWidget;
export '/pages/admin/crear_producto/crear_producto_widget.dart'
    show CrearProductoWidget;
export '/pages/normal_user/menu/menu_widget.dart' show MenuWidget;
export '/pages/normal_user/agendar_cita/agendar_cita_widget.dart'
    show AgendarCitaWidget;
export '/pages/normal_user/seleccionar_barbero/seleccionar_barbero_widget.dart'
    show SeleccionarBarberoWidget;
export '/pages/admin/empleados/empleados_widget.dart' show EmpleadosWidget;
export '/pages/auth/login/login_widget.dart' show LoginWidget;
export '/pages/auth/register/register_widget.dart' show RegisterWidget;
export '/error_compartido/error_compartido_widget.dart'
    show ErrorCompartidoWidget;
export '/pages/normal_user/carrito/carrito_widget.dart' show CarritoWidget;
export '/pages/normal_user/settings/settings_widget.dart' show SettingsWidget;
export '/pages/normal_user/citas/citas_widget.dart' show CitasWidget;
export '/pages/admin/lista_pedidos/lista_pedidos_widget.dart'
    show ListaPedidosWidget;
export '/pages/admin/contadores/contadores_widget.dart' show ContadoresWidget;
export '/pages/admin/menu_admin/menu_admin_widget.dart' show MenuAdminWidget;
export '/pages/normal_user/vista_producto/vista_producto_widget.dart'
    show VistaProductoWidget;
export '/pages/admin/servicio_editar/servicio_editar_widget.dart'
    show ServicioEditarWidget;
export '/pages/admin/servicio_agregar/servicio_agregar_widget.dart'
    show ServicioAgregarWidget;
export '/pages/admin/servicios/servicios_widget.dart' show ServiciosWidget;
export '/pages/admin/editar_empleado/editar_empleado_widget.dart'
    show EditarEmpleadoWidget;
export '/pages/normal_user/confirmacion/confirmacion_widget.dart'
    show ConfirmacionWidget;
export '/pages/admin/ventas_totales/ventas_totales_widget.dart'
    show VentasTotalesWidget;
export '/pages/admin/citas_administrador/citas_administrador_widget.dart'
    show CitasAdministradorWidget;
export '/pages/admin/usuarios_registrados/usuarios_registrados_widget.dart'
    show UsuariosRegistradosWidget;
export '/pages/admin/agregar_servicio_cita/agregar_servicio_cita_widget.dart'
    show AgregarServicioCitaWidget;
export '/pages/normal_user/agendar_hora/agendar_hora_widget.dart'
    show AgendarHoraWidget;
export '/pages/normal_user/editar_cita/editar_cita_widget.dart'
    show EditarCitaWidget;
export '/pages/admin/registrar_servicios/registrar_servicios_widget.dart'
    show RegistrarServiciosWidget;
export '/pages/admin/productos_c_r_u_d/productos_c_r_u_d_widget.dart'
    show ProductosCRUDWidget;
export '/pages/admin/producto_editar/producto_editar_widget.dart'
    show ProductoEditarWidget;
export '/pages/admin/tabla_rendimiento/tabla_rendimiento_widget.dart'
    show TablaRendimientoWidget;
export '/pages/admin/generar_reportes/generar_reportes_widget.dart'
    show GenerarReportesWidget;
export '/pages/admin/seleccion_periodos_servicios/seleccion_periodos_servicios_widget.dart'
    show SeleccionPeriodosServiciosWidget;
export '/pages/admin/informacion_cliente/informacion_cliente_widget.dart'
    show InformacionClienteWidget;
export '/pages/admin/consulta_servicios_i_n_f_o_r_m_a_l_e_s/consulta_servicios_i_n_f_o_r_m_a_l_e_s_widget.dart'
    show ConsultaServiciosINFORMALESWidget;
export '/pages/admin/seleccion_periodos_productos/seleccion_periodos_productos_widget.dart'
    show SeleccionPeriodosProductosWidget;
export '/pages/admin/citas_babrbero/citas_babrbero_widget.dart'
    show CitasBabrberoWidget;
export '/pages/admin/historial_cliente/historial_cliente_widget.dart'
    show HistorialClienteWidget;
export '/pages/admin/citas_barberos/citas_barberos_widget.dart'
    show CitasBarberosWidget;
export '/pages/admin/citas_barbero_registro/citas_barbero_registro_widget.dart'
    show CitasBarberoRegistroWidget;
export '/pages/admin/reportes_servicios/reportes_servicios_widget.dart'
    show ReportesServiciosWidget;
export '/pages/normal_user/comentario_users/comentario_users_widget.dart'
    show ComentarioUsersWidget;
export '/pages/admin/comenatrios_a_d_m/comenatrios_a_d_m_widget.dart'
    show ComenatriosADMWidget;
