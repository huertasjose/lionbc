import '/flutter_flow/flutter_flow_util.dart';
import 'citas_barbero_registro_widget.dart' show CitasBarberoRegistroWidget;
import 'package:flutter/material.dart';

class CitasBarberoRegistroModel
    extends FlutterFlowModel<CitasBarberoRegistroWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
