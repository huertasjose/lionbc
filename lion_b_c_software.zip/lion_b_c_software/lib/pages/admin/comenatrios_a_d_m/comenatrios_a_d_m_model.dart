import '/flutter_flow/flutter_flow_util.dart';
import 'comenatrios_a_d_m_widget.dart' show ComenatriosADMWidget;
import 'package:flutter/material.dart';

class ComenatriosADMModel extends FlutterFlowModel<ComenatriosADMWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
