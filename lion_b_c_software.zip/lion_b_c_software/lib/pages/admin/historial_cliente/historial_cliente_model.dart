import '/flutter_flow/flutter_flow_util.dart';
import 'historial_cliente_widget.dart' show HistorialClienteWidget;
import 'package:flutter/material.dart';

class HistorialClienteModel extends FlutterFlowModel<HistorialClienteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
