import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'servicio_editar_widget.dart' show ServicioEditarWidget;
import 'package:flutter/material.dart';

class ServicioEditarModel extends FlutterFlowModel<ServicioEditarWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Read Document] action in ServicioEditar widget.
  ServiciosRecord? obtenerServicio;
  // State field(s) for Servicio widget.
  FocusNode? servicioFocusNode;
  TextEditingController? servicioTextController;
  String? Function(BuildContext, String?)? servicioTextControllerValidator;
  // State field(s) for Descripcion widget.
  FocusNode? descripcionFocusNode;
  TextEditingController? descripcionTextController;
  String? Function(BuildContext, String?)? descripcionTextControllerValidator;
  // State field(s) for Precio widget.
  FocusNode? precioFocusNode;
  TextEditingController? precioTextController;
  String? Function(BuildContext, String?)? precioTextControllerValidator;
  // State field(s) for Duracion widget.
  FocusNode? duracionFocusNode;
  TextEditingController? duracionTextController;
  String? Function(BuildContext, String?)? duracionTextControllerValidator;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    servicioFocusNode?.dispose();
    servicioTextController?.dispose();

    descripcionFocusNode?.dispose();
    descripcionTextController?.dispose();

    precioFocusNode?.dispose();
    precioTextController?.dispose();

    duracionFocusNode?.dispose();
    duracionTextController?.dispose();
  }
}
