import '/flutter_flow/flutter_flow_util.dart';
import 'consulta_servicios_i_n_f_o_r_m_a_l_e_s_widget.dart'
    show ConsultaServiciosINFORMALESWidget;
import 'package:flutter/material.dart';

class ConsultaServiciosINFORMALESModel
    extends FlutterFlowModel<ConsultaServiciosINFORMALESWidget> {
  ///  Local state fields for this page.

  String? searchText = '';

  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
