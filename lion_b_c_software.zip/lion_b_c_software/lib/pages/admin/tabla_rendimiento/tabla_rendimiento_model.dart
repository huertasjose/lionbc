import '/flutter_flow/flutter_flow_util.dart';
import 'tabla_rendimiento_widget.dart' show TablaRendimientoWidget;
import 'package:flutter/material.dart';

class TablaRendimientoModel extends FlutterFlowModel<TablaRendimientoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
