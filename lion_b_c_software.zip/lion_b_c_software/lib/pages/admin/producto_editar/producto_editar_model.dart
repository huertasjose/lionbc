import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'producto_editar_widget.dart' show ProductoEditarWidget;
import 'package:flutter/material.dart';

class ProductoEditarModel extends FlutterFlowModel<ProductoEditarWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Read Document] action in ProductoEditar widget.
  ProductosRecord? obtenerServicio;
  // State field(s) for Nombre widget.
  FocusNode? nombreFocusNode;
  TextEditingController? nombreTextController;
  String? Function(BuildContext, String?)? nombreTextControllerValidator;
  // State field(s) for Descripcion widget.
  FocusNode? descripcionFocusNode;
  TextEditingController? descripcionTextController;
  String? Function(BuildContext, String?)? descripcionTextControllerValidator;
  // State field(s) for PrecioCompra widget.
  FocusNode? precioCompraFocusNode;
  TextEditingController? precioCompraTextController;
  String? Function(BuildContext, String?)? precioCompraTextControllerValidator;
  // State field(s) for Precio widget.
  FocusNode? precioFocusNode;
  TextEditingController? precioTextController;
  String? Function(BuildContext, String?)? precioTextControllerValidator;
  // State field(s) for Proveedor widget.
  FocusNode? proveedorFocusNode;
  TextEditingController? proveedorTextController;
  String? Function(BuildContext, String?)? proveedorTextControllerValidator;
  // State field(s) for Cant widget.
  FocusNode? cantFocusNode;
  TextEditingController? cantTextController;
  String? Function(BuildContext, String?)? cantTextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  List<String>? get choiceChipsValues => choiceChipsValueController?.value;
  set choiceChipsValues(List<String>? val) =>
      choiceChipsValueController?.value = val;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nombreFocusNode?.dispose();
    nombreTextController?.dispose();

    descripcionFocusNode?.dispose();
    descripcionTextController?.dispose();

    precioCompraFocusNode?.dispose();
    precioCompraTextController?.dispose();

    precioFocusNode?.dispose();
    precioTextController?.dispose();

    proveedorFocusNode?.dispose();
    proveedorTextController?.dispose();

    cantFocusNode?.dispose();
    cantTextController?.dispose();
  }
}
