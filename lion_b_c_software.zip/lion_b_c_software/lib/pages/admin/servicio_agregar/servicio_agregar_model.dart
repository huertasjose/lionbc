import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'servicio_agregar_widget.dart' show ServicioAgregarWidget;
import 'package:flutter/material.dart';

class ServicioAgregarModel extends FlutterFlowModel<ServicioAgregarWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Servicio widget.
  FocusNode? servicioFocusNode;
  TextEditingController? servicioTextController;
  String? Function(BuildContext, String?)? servicioTextControllerValidator;
  String? _servicioTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'm6ctx466' /* Nombre del servicio es requeri... */,
      );
    }

    if (val.length < 2) {
      return 'Requires at least 2 characters.';
    }

    return null;
  }

  // State field(s) for Descripcion widget.
  FocusNode? descripcionFocusNode;
  TextEditingController? descripcionTextController;
  String? Function(BuildContext, String?)? descripcionTextControllerValidator;
  String? _descripcionTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'dzo9tjr2' /* Describir los detalles del ser... */,
      );
    }

    if (val.length < 5) {
      return 'Requires at least 5 characters.';
    }

    return null;
  }

  // State field(s) for Precio widget.
  FocusNode? precioFocusNode;
  TextEditingController? precioTextController;
  String? Function(BuildContext, String?)? precioTextControllerValidator;
  String? _precioTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'bn7159y4' /* Precio es requerido */,
      );
    }

    if (val.length < 1) {
      return 'Requires at least 1 characters.';
    }

    return null;
  }

  // State field(s) for Duracion widget.
  FocusNode? duracionFocusNode;
  TextEditingController? duracionTextController;
  String? Function(BuildContext, String?)? duracionTextControllerValidator;
  String? _duracionTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'qihn1gtl' /* Duración es requerido */,
      );
    }

    if (val.length < 1) {
      return 'Requires at least 1 characters.';
    }

    return null;
  }

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {
    servicioTextControllerValidator = _servicioTextControllerValidator;
    descripcionTextControllerValidator = _descripcionTextControllerValidator;
    precioTextControllerValidator = _precioTextControllerValidator;
    duracionTextControllerValidator = _duracionTextControllerValidator;
  }

  @override
  void dispose() {
    servicioFocusNode?.dispose();
    servicioTextController?.dispose();

    descripcionFocusNode?.dispose();
    descripcionTextController?.dispose();

    precioFocusNode?.dispose();
    precioTextController?.dispose();

    duracionFocusNode?.dispose();
    duracionTextController?.dispose();
  }
}
