import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'citas_barberos_widget.dart' show CitasBarberosWidget;
import 'package:flutter/material.dart';

class CitasBarberosModel extends FlutterFlowModel<CitasBarberosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
