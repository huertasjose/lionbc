import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'seleccion_periodos_productos_widget.dart'
    show SeleccionPeriodosProductosWidget;
import 'package:flutter/material.dart';

class SeleccionPeriodosProductosModel
    extends FlutterFlowModel<SeleccionPeriodosProductosWidget> {
  ///  Local state fields for this page.

  bool verPDF = false;

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Reporte de Servicios)] action in Button widget.
  ApiCallResponse? apiResultfgy;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
