import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'empleados_widget.dart' show EmpleadosWidget;
import 'package:flutter/material.dart';

class EmpleadosModel extends FlutterFlowModel<EmpleadosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
