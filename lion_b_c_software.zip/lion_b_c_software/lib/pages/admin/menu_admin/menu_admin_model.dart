import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'menu_admin_widget.dart' show MenuAdminWidget;
import 'package:flutter/material.dart';

class MenuAdminModel extends FlutterFlowModel<MenuAdminWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
