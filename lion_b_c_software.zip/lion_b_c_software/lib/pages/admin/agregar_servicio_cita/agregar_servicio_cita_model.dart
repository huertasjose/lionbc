import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'agregar_servicio_cita_widget.dart' show AgregarServicioCitaWidget;
import 'package:flutter/material.dart';

class AgregarServicioCitaModel
    extends FlutterFlowModel<AgregarServicioCitaWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
