import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'productos_c_r_u_d_widget.dart' show ProductosCRUDWidget;
import 'package:flutter/material.dart';

class ProductosCRUDModel extends FlutterFlowModel<ProductosCRUDWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for propertyAddress widget.
  String? propertyAddressValue;
  FormFieldController<String>? propertyAddressValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
