import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'usuarios_registrados_widget.dart' show UsuariosRegistradosWidget;
import 'package:flutter/material.dart';

class UsuariosRegistradosModel
    extends FlutterFlowModel<UsuariosRegistradosWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Read Document] action in UsuariosRegistrados widget.
  UsersRecord? getRol;
  // State field(s) for Checkbox widget.
  Map<UsersRecord, bool> checkboxValueMap = {};
  List<UsersRecord> get checkboxCheckedItems =>
      checkboxValueMap.entries.where((e) => e.value).map((e) => e.key).toList();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
