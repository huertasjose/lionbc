import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import '/index.dart';
import 'agendar_hora_widget.dart' show AgendarHoraWidget;
import 'package:flutter/material.dart';

class AgendarHoraModel extends FlutterFlowModel<AgendarHoraWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  // Stores action output result for [Firestore Query - Query a collection] action in Button widget.
  List<CitasRecord>? citaEncontrada;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
