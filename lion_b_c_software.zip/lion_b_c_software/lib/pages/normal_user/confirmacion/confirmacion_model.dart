import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'confirmacion_widget.dart' show ConfirmacionWidget;
import 'package:flutter/material.dart';

class ConfirmacionModel extends FlutterFlowModel<ConfirmacionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
