import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'carrito_widget.dart' show CarritoWidget;
import 'package:flutter/material.dart';

class CarritoModel extends FlutterFlowModel<CarritoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
