import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'vista_producto_widget.dart' show VistaProductoWidget;
import 'package:flutter/material.dart';

class VistaProductoModel extends FlutterFlowModel<VistaProductoWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Read Document] action in VistaProducto widget.
  ProductosRecord? obtenerProducto;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  CarritoRecord? productoCreado;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
