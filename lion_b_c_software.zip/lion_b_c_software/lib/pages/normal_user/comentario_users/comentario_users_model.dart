import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'comentario_users_widget.dart' show ComentarioUsersWidget;
import 'package:flutter/material.dart';

class ComentarioUsersModel extends FlutterFlowModel<ComentarioUsersWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  String? _textControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return FFLocalizations.of(context).getText(
        'q1jnkb2h' /* Escribe tus comentarios aquí e... */,
      );
    }

    if (val.length < 5) {
      return FFLocalizations.of(context).getText(
        'bqnskj1i' /* Tu mensaje debe ser más largo  */,
      );
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    textControllerValidator = _textControllerValidator;
  }

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
